import CodeProjectEditor, { Script } from './project-editor';

export default CodeProjectEditor;
export {
    Script
}
