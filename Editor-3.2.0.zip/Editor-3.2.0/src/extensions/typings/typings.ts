export interface IStringDictionary<T> {
    [index: string]: T;
}
